<?php

class database
{
    public $host = "localhost";
    public $user = "root";
    public $password = "";
    public $database = "project_class";
    public $conn;
    public $_sql = "";

    public function __construct()
    {
        try {
            $this->conn = new mysqli($this->host, $this->user, $this->password, $this->database);
        } catch (Exception $e) {
            echo "Error:" . $e->getMessage();
        }
    }

    public function select($vars = "*", $table, $join = "", $where = "", $groupby = "", $orderby = "")
    {
        if ($vars != "*") {
            if (is_array($vars)) {
                $vars = implode(",", $vars);
            }
        }
        $selectSql = "SELECT " . $vars . " FROM " . $table;
        // print_r($selectSql);die();
        if ($join !== "") {
            $selectSql .= " " . $join;
        }
        if ($where !== "") {
            $selectSql .= ' WHERE ' . $where;
            // print_r($selectSql);die();
        }
        if ($groupby !== "") {
            $selectSql .= ' GROUP BY ' . $groupby;
            // print_r($selectSql);die();
        }
        if ($orderby !== "") {
            $selectSql .= ' ORDER BY ' . $orderby;
        }
        // print_r($selectSql);
        // die();

        $results = mysqli_query($this->conn, $selectSql);
        // print_r($results);die();
        return $results;

        // $row=mysqli_fetch_assoc($results);
        // return $row;
        // print_r($row);
        // die;

    }

    public function insert($table, $dbFields)
    {
        $fields = array();
        $value = array();
        // print_r($dbFields);die();
        foreach ($dbFields as $k => $v) {
            $v = (stripslashes($v));
            $fields[] = $k;
            $qmark[] = "'" . $v . "'";
            $value[":" . $k] = $v;
        }

        $f = implode("`,`", $fields);
        $q = implode(",", $qmark);
        $val = implode("','", $value);

        $insertSql = "INSERT INTO `$table` (`$f`) VALUES ($q)";
        // print_r($insertSql);die();
        $stmt = $this->conn->prepare($insertSql);
        $stmt->execute();
        return $stmt;
    }

    public function getInsertId()
    {
        $_result = mysqli_insert_id($this->conn);
        $this->_insertId = $_result;
        return $_result;
    }

    public function update($table, $dbFields, $where)
    {

        $updateSql = "UPDATE $table SET ";
        $i = 0;
        $values = array();

        foreach ($dbFields as $k => $v) {

            if ($i == 0) {
                $updateSql .= " $k = '$v'";
            } else {
                $updateSql .= ", $k = '$v' ";
            }

            $values[] = $v;
            $i++;
        }

        $updateSql .= "WHERE $where";
        $stmt = $this->conn->prepare($updateSql);
        $_result = $stmt->execute();
        // print_r($_result);die();
        return $_result;
    }

    public function delete($var = '', $table, $join = '', $where)
    {
        $deleteSql = "DELETE ";
        if ($var !== '') {
            $deleteSql .= " " . $var . " FROM " . $table;
        } else {
            $deleteSql .= "FROM " . $table;
        }

        if ($join !== '') {
            $deleteSql .= " " . $join;
        }
        if ($where != '') {
            $deleteSql .= ' WHERE ' . $where;
        }
        // print_r($deleteSql);
        // die();
        // $results = mysqli_query($this->conn, $deleteSql);

        $stmt = $this->conn->prepare($deleteSql);
        $stmt->execute();
        // return $results;
    }

    public function query($sql)
    {
        $array = array();
        $result = mysqli_query($this->conn, $sql);
        // print_r($result);die();
        while ($row = mysqli_fetch_assoc($result)) {
            $array[] = $row;
        }
        // print_r($array);die();
        return $array;
    }

    function createImage($images)
    {
        global $original_height;
        global $original_width;
        global $imgt;
        global $imgcreatefrom;
        global $folder;
        global $fdir;
        global $images;
        global $directory;
        global $productdir;

        $folder = "uploads/category/thumbnail/";
        $productFolder = "uploads/product/thumbnail/";

        $images = $_FILES['image']['name'];
        $tempname = $_FILES['image']['tmp_name'];
        $images = time() . '-' . rand() . '-' . $images;
        $fdir = $folder . $images;
        $productdir = $productFolder . $images;
        $directory = "uploads/category/" . $images;
        $arr_image_details = getimagesize($tempname);

        $original_width = $arr_image_details[0];
        $original_height = $arr_image_details[1];
        if ($arr_image_details[2] == IMAGETYPE_GIF) {
            $imgt = "ImageGIF";
            $imgcreatefrom = "ImageCreateFromGIF";
        }
        if ($arr_image_details[2] == IMAGETYPE_JPEG) {
            $imgt = "ImageJPEG";
            $imgcreatefrom = "ImageCreateFromJPEG";
        }
        if ($arr_image_details[2] == IMAGETYPE_PNG) {
            $imgt = "ImagePNG";
            $imgcreatefrom = "ImageCreateFromPNG";
        }
    }
    public function createCategoryThumb($images)
    {
        global $original_height;
        global $thumbnail_height;
        global $thumbnail_height;
        global $original_width;
        global $imgt;
        global $imgcreatefrom;
        global $fdir;
        $thumbnail_width = 100;
        $thumbnail_height = 100;
        if ($original_width > $original_height) {
            $new_width = $thumbnail_width;
            $new_height = intval($original_height * $new_width / $original_width);
        } else {
            $new_height = $thumbnail_height;
            $new_width = intval($original_width * $new_height / $original_height);
        }

        $dest_x = intval(($thumbnail_width - $new_width) / 2);
        $dest_y = intval(($thumbnail_height - $new_height) / 2);

        if ($imgt) {
            $old_image = $imgcreatefrom($_FILES['image']['tmp_name']);
            $new_image = imagecreatetruecolor($thumbnail_width, $thumbnail_height);
            imagecopyresized($new_image, $old_image, $dest_x, $dest_y, 0, 0, $new_width, $new_height, $original_width, $original_height);
            $imgt($new_image, $fdir);
        }
    }

    public function cropCategoryImage($images)
    {
        global $original_height;
        global $original_width;
        global $imgt;
        global $imgcreatefrom;

        global $directory;
        $full_width = 1024;
        $full_height = 720;
        if ($original_width > $original_height) {
            $new_width = $full_width;
            $new_height = intval($original_height * $new_width / $original_width);
        } else {
            $new_height = $full_height;
            $new_width = intval($original_width * $new_height / $original_height);
        }

        $dest_x = intval(($full_width - $new_width) / 2);
        $dest_y = intval(($full_height - $new_height) / 2);

        if ($imgt) {
            $old_image = $imgcreatefrom($_FILES['image']['tmp_name']);
            $new_image = imagecreatetruecolor($full_width, $full_height);
            imagecopyresized($new_image, $old_image, $dest_x, $dest_y, 0, 0, $new_width, $new_height, $original_width, $original_height);
            // imagejpeg($new_image, $folder);
            $imgt($new_image, $directory);
        }
    }
    public function productImage($images)
    {
        global $images;
        global $tempFile;
        global $original_height;
        global $original_width;
        global $productdir;
        global $directory;
        global $imgt;
        global $imgcreatefrom;

        $productFolder = "uploads/product/thumbnail/";
        $productdir = $productFolder . $images;
        $directory = "uploads/product/" . $images;
        $arr_image_details = getimagesize($tempFile);
        $original_width = $arr_image_details[0];
        $original_height = $arr_image_details[1];

        if ($arr_image_details[2] == IMAGETYPE_GIF) {
            $imgt = "ImageGIF";
            $imgcreatefrom = "ImageCreateFromGIF";
        }
        if ($arr_image_details[2] == IMAGETYPE_JPEG) {
            $imgt = "ImageJPEG";
            $imgcreatefrom = "ImageCreateFromJPEG";
        }
        if ($arr_image_details[2] == IMAGETYPE_PNG) {
            $imgt = "ImagePNG";
            $imgcreatefrom = "ImageCreateFromPNG";
        }
    }
    public function createProductThumb($images)
    {
        global $original_height;
        global $thumbnail_height;
        global $thumbnail_height;
        global $original_width;
        global $imgcreatefrom;
        global $imgt;
        global $key;
        global $productdir;
        $thumbnail_width = 100;
        $thumbnail_height = 100;
        if ($original_width > $original_height) {
            $new_width = $thumbnail_width;
            $new_height = intval($original_height * $new_width / $original_width);
        } else {
            $new_height = $thumbnail_height;
            $new_width = intval($original_width * $new_height / $original_height);
        }

        $dest_x = intval(($thumbnail_width - $new_width) / 2);
        $dest_y = intval(($thumbnail_height - $new_height) / 2);

        if ($imgt) {
            $old_image = $imgcreatefrom($_FILES['image']['tmp_name'][$key]);
            $new_image = imagecreatetruecolor($thumbnail_width, $thumbnail_height);

            imagecopyresized($new_image, $old_image, $dest_x, $dest_y, 0, 0, $new_width, $new_height, $original_width, $original_height);
            $imgt($new_image, $productdir);
        }
    }
    public function cropProductImage($images)
    {
        global $original_height;
        global $thumbnail_height;
        global $thumbnail_height;
        global $original_width;
        global $imgcreatefrom;
        global $imgt;
        global $key;
        global $directory;
        $thumbnail_width = 1024;
        $thumbnail_height = 720;
        if ($original_width > $original_height) {
            $new_width = $thumbnail_width;
            $new_height = intval($original_height * $new_width / $original_width);
        } else {
            $new_height = $thumbnail_height;
            $new_width = intval($original_width * $new_height / $original_height);
        }

        $dest_x = intval(($thumbnail_width - $new_width) / 2);
        $dest_y = intval(($thumbnail_height - $new_height) / 2);

        if ($imgt) {
            $old_image = $imgcreatefrom($_FILES['image']['tmp_name'][$key]);
            $new_image = imagecreatetruecolor($thumbnail_width, $thumbnail_height);

            imagecopyresized($new_image, $old_image, $dest_x, $dest_y, 0, 0, $new_width, $new_height, $original_width, $original_height);
            $imgt($new_image, $directory);
        }
    }
}
